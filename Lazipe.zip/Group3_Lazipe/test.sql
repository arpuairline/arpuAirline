-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2016 at 03:55 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `c_mId` int(10) NOT NULL,
  `cTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `c_iId` int(10) NOT NULL,
  `cAmount` int(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`c_mId`, `cTime`, `c_iId`, `cAmount`) VALUES
(100011, '2016-05-11 10:48:32', 3, 1),
(100011, '2016-05-11 10:53:53', 4, 1),
(100011, '2016-05-11 11:10:52', 7, 1);

--
-- Triggers `cart`
--
DELIMITER //
CREATE TRIGGER `add_cart` AFTER INSERT ON `cart`
 FOR EACH ROW begin
 insert into cart_log values (null, new.c_mId, null, new.c_iId, new.cAmount);
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cart_log`
--

CREATE TABLE IF NOT EXISTS `cart_log` (
`cLog_id` int(5) NOT NULL,
  `c_mId` int(10) NOT NULL,
  `cTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `c_iId` int(10) NOT NULL,
  `cAmount` int(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=100014 ;

--
-- Dumping data for table `cart_log`
--

INSERT INTO `cart_log` (`cLog_id`, `c_mId`, `cTime`, `c_iId`, `cAmount`) VALUES
(100012, 100011, '2016-05-11 10:53:53', 4, 1),
(100013, 100011, '2016-05-11 11:10:52', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ingredforrecipe`
--

CREATE TABLE IF NOT EXISTS `ingredforrecipe` (
  `rId` int(5) NOT NULL,
  `iId` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ingredforrecipe`
--

INSERT INTO `ingredforrecipe` (`rId`, `iId`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(4, 6),
(5, 7),
(6, 8),
(6, 9),
(7, 10),
(8, 11),
(9, 12),
(10, 13),
(10, 14),
(11, 15),
(12, 4),
(12, 16),
(12, 17),
(12, 21),
(13, 17),
(14, 18),
(15, 11),
(15, 19),
(15, 20),
(16, 21),
(17, 22),
(18, 16),
(19, 23),
(20, 24);

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE IF NOT EXISTS `ingredients` (
`iId` int(11) NOT NULL,
  `iName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `iType` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `iSource` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `iUnitPrice` decimal(6,2) NOT NULL,
  `iPhoto` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`iId`, `iName`, `iType`, `iSource`, `iUnitPrice`, `iPhoto`) VALUES
(1, '鬆餅粉', '粉類', '日本', '50.00', '1.jpg'),
(2, '抹茶粉', '粉類', '日本', '120.00', '2.jpg'),
(3, '黑糖', '調味', '台南', '60.00', '4.jpg'),
(4, '糯米粉', '粉類', '南投', '80.00', '3.jpg'),
(5, '花生粉', '粉類', '花蓮', '40.00', '5.jpg'),
(6, '巧克力醬', '其他', '歐洲', '100.00', '6.jpg'),
(7, '洋菜粉', '粉類', '台南', '30.00', '7.jpg'),
(8, '白木耳', '蔬菜', '高雄', '80.00', '8.jpg'),
(9, '枸杞', '蔬菜', '屏東', '100.00', '9.jpg'),
(10, '羊肚菇', '蔬菜', '屏東', '60.00', '10.jpg'),
(11, '馬鈴薯', '蔬菜', '嘉義', '100.00', '11.jpg'),
(12, '老母雞', '肉類', '嘉義', '210.00', '12.jpg'),
(13, '起司粉', '粉類', '美國', '180.00', '13.jpg'),
(14, '巴西利', '調味', '歐洲', '120.00', '14.jpg'),
(15, '濃湯罐頭', '其他', '美國', '30.00', '15.jpg'),
(16, '油蔥酥', '調味', '台南', '80.00', '16.jpg'),
(17, '雞粉', '調味', '台東', '60.00', '17.jpg'),
(18, '玉米粉', '粉類', '台東', '60.00', '18.jpg'),
(19, '月桂葉', '調味', '歐洲', '80.00', '19.jpg'),
(20, '陳皮', '調味', '高雄', '70.00', '20.jpg'),
(21, '荷葉', '其他', '台南', '20.00', '21.jpg'),
(22, '麵包粉', '粉類', '台中', '40.00', '22.jpg'),
(23, '和風醬', '調味', '日本', '45.00', '23.jpg'),
(24, '香魚', '肉類', '日本', '80.00', '24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
`mID` int(10) NOT NULL,
  `mAccount` varchar(30) NOT NULL,
  `mPassword` varchar(20) NOT NULL,
  `mName` varchar(10) NOT NULL,
  `mAddress` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `mPhone` char(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100013 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mID`, `mAccount`, `mPassword`, `mName`, `mAddress`, `mPhone`) VALUES
(100001, 'test1', '1234', 'J', '台北文山區指南路', '098827377'),
(100002, 'test2', '123', 'Amy', '台北市文山區指南路二段64號', '09812908'),
(100003, 'test3', '1234', 'Chris', '新北市林口區文化三路一段356號', '09238273'),
(100004, 'test4', '1234', 'Justin', '花蓮縣花蓮市德安一街225號', '09263812'),
(100005, 'test213', '21321312', 'hey', 'eqweijqljeqkj', '098273611'),
(100006, 'wqeqweqwe', '2312wewq', 'Danny', '台北', '092838211'),
(100009, 'test1234', '21wkejqw', 'DATE(Lily)', '桃園縣中壢市', '092837466'),
(100010, 'test123', 'wkejkwqje', 'Jessie', '台北市', '098273622'),
(100011, 'chi', 'chi123', 'chichi', '台北市', '0954321845');

-- --------------------------------------------------------

--
-- Table structure for table `recipe`
--

CREATE TABLE IF NOT EXISTS `recipe` (
`rId` int(5) NOT NULL,
  `rPic` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `rName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `rCont` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rIngred` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `rType` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `recipe`
--

INSERT INTO `recipe` (`rId`, `rPic`, `rName`, `rCont`, `rIngred`, `rType`) VALUES
(1, '01.png', '抹茶銅鑼燒', '01_step.png', '01_i.png', '日式甜點'),
(2, '02.png', '黑糖紅豆麻糬', '02_step.png', '02_i.png', '日式甜點'),
(3, '03.png', '核桃酪', '03_step.png', '03_i.png', '中式甜點'),
(4, '04.png', '英國香蕉米布丁', '04_step.png', '04_i.png', '西式甜點'),
(5, '05.png', '草莓奶凍', '05_step.png', '05_i.png', '西式甜點'),
(7, '06.png', '冰糖素燕窩', '06_step.png', '06_i.png', '中式甜點'),
(8, '07.png', '百菇湯', '07_step.png', '07_i.png', '中式料理'),
(9, '08.png', '奶油馬鈴薯濃湯', '08_step.png', '08_i.png', '西式料理'),
(10, '09.png', '雞上湯', '09_step.png', '09_i.png', '中式料理'),
(11, '10.png', '青醬拌飯', '10_step.png', '10_i.png', '西式料理'),
(12, '11.jpg', '法國蘑菇起司飯', '11_step.png', '11_i.png', '西式料理'),
(13, '12.jpg', '荷葉油飯', '12_step.png', '12_i.png', '中式料理'),
(14, '13.jpg', '竹筍飯', '13_step.png', '13_i.png', '中式料理'),
(15, '14.jpg', '乳香羊排', '14_step.png', '14_i.png', '中式料理'),
(16, '15.jpg', '清燉牛腩', '15_step.png', '15_i.png', '中式料理'),
(17, '16.jpg', '桶仔雞', '16_step.png', '16_i.png', '中式料理'),
(18, '17.jpg', '藍帶豬排', '17_step.png', '17_i.png', '西式料理'),
(19, '18.jpg', '滷肉飯', '18_step.png', '18_i.png', '中式料理'),
(20, '19.jpg', '和風燒透抽', '19_step.png', '19_i.png', '日式料理'),
(21, '20.jpg', '蜜香魚', '20_step.png', '20_i.png', '日式料理');

-- --------------------------------------------------------

--
-- Table structure for table `transaction2`
--

CREATE TABLE IF NOT EXISTS `transaction2` (
`tId` int(11) NOT NULL,
  `tTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tTotalPrice` decimal(6,2) NOT NULL,
  `tPayMethod` int(1) NOT NULL,
  `tName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tPhone` int(10) NOT NULL,
  `tAdd` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `t_iName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `t_iAmount` int(10) NOT NULL,
  `t_mId` int(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8042 ;

--
-- Dumping data for table `transaction2`
--

INSERT INTO `transaction2` (`tId`, `tTime`, `tTotalPrice`, `tPayMethod`, `tName`, `tPhone`, `tAdd`, `t_iName`, `t_iAmount`, `t_mId`) VALUES
(3, '2016-05-09 15:43:49', '300.00', 1, '孫', 123456, '中', '粉', 5, 100001),
(4, '2016-05-09 15:43:49', '300.00', 1, '孫', 123456, '中', '粉', 5, 100001),
(5, '2016-05-09 15:43:49', '300.00', 1, '孫', 123456, '中', '粉', 5, 100001),
(6, '2016-05-09 15:56:37', '1800.00', 0, 'Amy', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 6, 100002),
(7, '2016-05-09 15:56:37', '1800.00', 0, 'Amy', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 8, 100002),
(8, '2016-05-09 15:56:37', '1800.00', 0, 'Amy', 9812908, '台北市文山區指南路二段64號', '黑糖', 9, 100002),
(9, '2016-05-09 16:04:29', '1060.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 4, 100002),
(10, '2016-05-09 16:04:29', '1060.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 5, 100002),
(11, '2016-05-09 16:04:29', '1060.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '黑糖', 3, 100002),
(12, '2016-05-09 16:06:48', '370.00', 1, '孫若庭', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 1, 100002),
(13, '2016-05-09 16:06:49', '370.00', 1, '孫若庭', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 1, 100002),
(14, '2016-05-09 16:06:49', '370.00', 1, '孫若庭', 9812908, '台北市文山區指南路二段64號', '黑糖', 2, 100002),
(15, '2016-05-09 16:08:58', '320.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 0, 100002),
(16, '2016-05-09 16:08:58', '320.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 1, 100002),
(17, '2016-05-09 16:08:58', '320.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '黑糖', 2, 100002),
(18, '2016-05-09 16:15:00', '300.00', 0, '哈哈哈哈哈', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 2, 100002),
(19, '2016-05-09 16:15:00', '300.00', 0, '哈哈哈哈哈', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 1, 100002),
(20, '2016-05-09 16:34:18', '180.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 2, 100002),
(21, '2016-05-09 16:34:18', '180.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 0, 100002),
(22, '2016-05-09 16:40:07', '330.00', 1, '幹', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 5, 100002),
(23, '2016-05-09 16:49:08', '130.00', 1, 'Amy', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 1, 100002),
(3869, '2016-05-09 17:25:58', '6540.00', 1, '978', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 78, 100002),
(4415, '2016-05-09 17:15:08', '690.00', 1, 'testbuying', 9812908, '文山區指南路二段64號', '鬆餅粉', 5, 100002),
(5192, '2016-05-09 17:16:17', '250.00', 1, 'c.3', 9812908, '12345', '鬆餅粉', 1, 100002),
(7878, '2016-05-09 17:11:35', '130.00', 1, '555555555', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 1, 100002),
(8023, '2016-05-09 17:22:51', '9000.00', 1, 'Amy22222', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 60, 100002),
(8024, '2016-05-09 17:32:03', '830.00', 1, 'Amy555', 9812908, '台北市文山區指南路二段64號', '鬆餅粉', 3, 100002),
(8025, '2016-05-09 17:32:03', '830.00', 1, 'Amy555', 9812908, '台北市文山區指南路二段64號', '抹茶粉', 5, 100002),
(8026, '2016-05-10 14:49:05', '580.00', 1, 'sunsun', 954321845, '樂華夜市', '巧克力醬', 5, 100011),
(8027, '2016-05-11 07:03:25', '840.00', 1, '余杯', 9812908, '台北市文山區指南路二段64號', '黑糖', 1, 100002),
(8028, '2016-05-11 07:03:25', '840.00', 1, '余杯', 9812908, '台北市文山區指南路二段64號', '花生粉', 2, 100002),
(8029, '2016-05-11 07:03:25', '840.00', 1, '余杯', 9812908, '台北市文山區指南路二段64號', '馬鈴薯', 3, 100002),
(8030, '2016-05-11 07:03:25', '840.00', 1, '余杯', 9812908, '台北市文山區指南路二段64號', '月桂葉', 4, 100002),
(8031, '2016-05-11 07:11:08', '1140.00', 1, '魚魚魚', 9812908, '台北市文山區指南路二段64號', '起司粉', 3, 100002),
(8032, '2016-05-11 07:11:09', '1140.00', 1, '魚魚魚', 9812908, '台北市文山區指南路二段64號', '巴西利', 5, 100002),
(8033, '2016-05-11 07:17:40', '960.00', 1, '哭哭', 9812908, '二段64號', '馬鈴薯', 7, 100002),
(8034, '2016-05-11 07:17:40', '960.00', 1, '哭哭', 9812908, '二段64號', '雞粉', 3, 100002),
(8035, '2016-05-11 07:22:45', '660.00', 1, '5566', 9812908, '台北市文山區指南路二段64號', '馬鈴薯', 1, 100002),
(8036, '2016-05-11 07:22:45', '660.00', 1, '5566', 9812908, '台北市文山區指南路二段64號', '巴西利', 4, 100002),
(8037, '2016-05-11 07:33:34', '660.00', 1, 'Amy555', 9812908, '台北市文山區指南路二段64號', '馬鈴薯', 1, 100002),
(8038, '2016-05-11 07:33:34', '660.00', 1, 'Amy555', 9812908, '台北市文山區指南路二段64號', '玉米粉', 8, 100002),
(8039, '2016-05-11 09:38:16', '680.00', 1, 'Amy987', 9812908, '台北市文山區指南路二段64號', '馬鈴薯', 6, 100002),
(8040, '2016-05-11 09:56:39', '180.00', 1, 'time', 9812908, '台北市文山區指南路二段64號', '馬鈴薯', 1, 100002),
(8041, '2016-05-11 08:08:47', '1440.00', 0, 'yo', 9812908, '台北市文山區指南路二段64號', '起司粉', 8, 100002);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
 ADD PRIMARY KEY (`c_mId`,`c_iId`), ADD KEY `c_iId` (`c_iId`);

--
-- Indexes for table `cart_log`
--
ALTER TABLE `cart_log`
 ADD PRIMARY KEY (`cLog_id`), ADD KEY `c_iId` (`c_iId`), ADD KEY `c_mId` (`c_mId`);

--
-- Indexes for table `ingredforrecipe`
--
ALTER TABLE `ingredforrecipe`
 ADD PRIMARY KEY (`rId`,`iId`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
 ADD PRIMARY KEY (`iId`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
 ADD PRIMARY KEY (`mID`);

--
-- Indexes for table `recipe`
--
ALTER TABLE `recipe`
 ADD PRIMARY KEY (`rId`);

--
-- Indexes for table `transaction2`
--
ALTER TABLE `transaction2`
 ADD PRIMARY KEY (`tId`), ADD KEY `tans_mid` (`t_mId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_log`
--
ALTER TABLE `cart_log`
MODIFY `cLog_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100014;
--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
MODIFY `iId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
MODIFY `mID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100013;
--
-- AUTO_INCREMENT for table `recipe`
--
ALTER TABLE `recipe`
MODIFY `rId` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `transaction2`
--
ALTER TABLE `transaction2`
MODIFY `tId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8042;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`c_mId`) REFERENCES `member` (`mID`),
ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`c_iId`) REFERENCES `ingredients` (`iId`);

--
-- Constraints for table `transaction2`
--
ALTER TABLE `transaction2`
ADD CONSTRAINT `transaction2_ibfk_1` FOREIGN KEY (`t_mId`) REFERENCES `member` (`mID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
