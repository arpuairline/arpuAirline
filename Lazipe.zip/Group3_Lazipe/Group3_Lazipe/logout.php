<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	session_start();
	unset($_SESSION['mAccount']);
	unset($_SESSION['mID']);
	session_destroy();
	echo "<script language='javascript'>alert('親～登出成功，歡迎再回來呦');window.location.href='product01.php';</script>";
?>
