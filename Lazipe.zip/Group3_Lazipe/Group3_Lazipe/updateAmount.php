<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">

<?php
	session_start();
  include("db.php");
  if(isset($_POST['amount']) && !empty($_POST['amount'])){
		$amount=$_POST['amount'];
	}else{
		$amount=0;
	}

  if(isset($_POST['c']) && !empty($_POST['c'])){
		$c=$_POST['c'];
	}else{
		$c=0;
	}

  if(isset($_POST['i']) && !empty($_POST['i'])){
		$i=$_POST['i'];
	}else{
		$i=0;
	}

  $sql="UPDATE `cart` SET `cAmount`='$amount' WHERE `c_mId`='$c' AND`c_iId`='$i'";//***********************
  $query=mysql_query($sql);

  if($amount==0){
    $sql2="DELETE FROM `cart` WHERE `c_mId`='$c' AND`c_iId`='$i'";
    $query2=mysql_query($sql2);
  }

?>
<script language='javascript'>location.href='Cart.php';</script>
