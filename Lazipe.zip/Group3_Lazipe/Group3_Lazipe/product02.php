﻿<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();
	$recipeId = $_GET['no'];
?>
<html>
<head>
<title>=Lazipe=</title>
</head>
<body background="img/bggg.png" style="background-repeat:no-repeat; background-position:center;" bgproperties="fixed">
<table border="0" cellpadding="0" cellspacing="0" width="100%" >
	<!--跨三行-->
	<tr>

	<!--顯示輸入帳號的區塊div-->
		<div align="left">
		<img border="0" src="img/top.png" width="45%" height="33%">
		<br /><br />

		<?php
			if(isset($_SESSION['mAccount']) && !empty($_SESSION['mAccount'])){
		?>
				<b><font face="華康采風體W3" size=4>您好！<?php echo $_SESSION['mAccount'];?></font></b>
				<b><font size="3" face="華康采風體W3"><a href="product01.php">  首頁  </a></font></b>
				<b><font size="3" face="華康采風體W3"><a href="Cart.php">  我的購物車  </a></font></b>
				<b><font size="3" face="華康采風體W3"><a href="jj/member.php">  會員中心  </a></font></b>
				<b><font size="3" face="華康采風體W3"><a href="logout.php">  登出</a></font></b>

		<?php
			}else{
		?>
				<form name="form1" method="post" action="jj/connect.php">
						<b><font face="華康采風體W3" size=4>會員登入</font></b>
						<b><font size="3" face="華康采風體W3">帳號</font></b>
						<label>
							<input name="mAccount" type="text" size="10">
						</label>
							<b><font size="3" face="華康采風體W3">密碼</font></b>
						<label>
							<input name="mPassword" type="password" size="10">
							<input type="submit" name="Submit" value="送出">
						</label>
						<a href="jj/register.php"><font size="3" face="華康采風體W3">註冊</font></a>
						<b><font size="3" face="華康采風體W3"><a href="product01.php">  首頁  </a></font></b>
				</form>
		<?php
			}
		?>
		</div>
		</td>
	</tr>


 <!-- 主區塊 START -->
	<td colspan="2" valign="top">
	<div align="center">
	<font face="華康采風體W3">
	<!--show recipe-->
	<table border="0" width="900" height="220">

<?php
	include("db.php");
	$sql = "SELECT `rId`, `rName`, `rType`, `rPic`, `rCont`, `rIngred` FROM `recipe` WHERE `rId` = ".$recipeId.";";
	$result = mysql_query ($sql) or die('MySQL query error'.mysql_error());
	$row = mysql_fetch_array($result);

	$All_Ingred = "SELECT A.iId, iName, iType, iSource, iUnitPrice, iPhoto FROM ingredients AS A INNER JOIN (SELECT iId FROM IngredForRecipe WHERE rId = ".$recipeId.") AS B ON A.iId = B.iId";
	$result_Ingred = mysql_query ($All_Ingred) or die('MySQL query error'.mysql_error());
?>

	<tr>
		<!--img-->
		<td align="center" height="220" width="200">
				<input  type="image"  width="150px" height="150px" name="rId" border="0" src="img/recipe/<?php echo $row['rPic'];?>"  onClick="location.href='product02.php?no=<?php echo $row['rId'];?>';" />
		</td>
		<!--detail-->
		<td colspan="2" align="left" height="55" width="200">
			<p><b><?php echo $row['rName'];?></b></p>
			<p><b><?php echo $row['rType'];?></b></p>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center">。<hr color="green"/></td>
	</tr>
	<!--list ingredient-->
	<tr>
		<td colspan="2" align="center">
			<font face="華康采風體W3" size="4"><b>
				購買食材
			</b></font>
		</td>
	</tr>
	<tr>
		<td align="center" valign="center" colspan="2">
			<table border="0">
				<tr>
					<?php
						while($row_Ingred = mysql_fetch_array($result_Ingred))
						{
					?>
							<td><img src='img/ingredient/<?php echo $row_Ingred['iPhoto'];?>' width='130px' height='130px'></td>
							<td><?php echo $row_Ingred['iName']."<br>種類:".$row_Ingred['iType']."<br>產地:".$row_Ingred['iSource']."<br>單價".$row_Ingred['iUnitPrice']?>
								<br>
								<form method="post" action="product_add_cart.php">
									<input type="hidden" name="r_id" value="<?php echo $row['rId'];?>">
									<input type="hidden" name="i_id" value="<?php echo $row_Ingred['iId'];?>">
									<input type="submit" value="加入購物車">
								</form>
							</td>
				<?php
						}//end while
					?>
				</tr>
			</table>
			<hr color="green"/></td>
		</td>

	</tr>

	<!--所需食材-->
	<tr>
		<td colspan="2" align="center">
			<font face="華康采風體W3" size="4"><b>
				所需食材
			</b></font>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<img src="img/recipe/<?php echo $row['rIngred'];?>">
		</td>
	</tr>
  <!--做法-->
	<tr>
		<td colspan="2" align="center">
			<font face="華康采風體W3" size="4"><b>
				食譜作法
			</b></font>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<img src="img/recipe/<?php echo $row['rCont'];?>">
		</td>
	</tr>

<?php
	mysql_close();
?>
	</table>
	</font>
	</div>
	</td>
  <!-- 主區塊 END -->
	</tr>
</table>
</body>
</html>
