

<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();
  include("db.php");
	$_SESSION['totalPrice']= 0;
	$_SESSION['time']= NULL;
	$mId=$_SESSION['mID'];

	if(isset($_POST['amount']) && !empty($_POST['amount'])){
		$amount=$_POST['amount'];
	}else{
		$amount=1;
	}
	if(isset($_GET['am'])){
		$test=$_GET['am'];
	}else{
		$test=1;
	}
?>
<html>
	<head>
    	<link rel="stylesheet" href="CSS/reset.css" />
        <link rel="stylesheet" href="CSS/style.css" />
        <title>Cart</title>
    </head>
    <body>

    	<div id="container"><h1>購物車</h1>
        	<div id="main">
<table>
	  <tr>
			  <th>商品名稱</th>
				<th>產地</th>
				<th>單價</th>
				<th>數量</th>
				<th>小計</th>
		</tr>
						<?php

						$sql="SELECT * FROM `cart` WHERE `c_mId`='$mId'";//******************
						$query=mysql_query($sql);

						while($row = mysql_fetch_array($query)){

						//echo "<br>會員帳號=",$row['c_mAccount'];
						//echo "<br>數量=",$row['cAmount'];
						$idnum=$row['c_iId'];
						$sql2="SELECT `iName`,`iSource`,`iUnitPrice` FROM `ingredients` WHERE `iId`='$idnum'";
						$query2=mysql_query($sql2);
						$row2 = mysql_fetch_array($query2);

						if($row['cAmount']!=0){
?>
<tr>
	<td><?php	echo $row2['iName'];?></td>
	<td><?php echo $row2['iSource'];?></td>
	<td><?php echo "$ ",$row2['iUnitPrice'];?></td>
  <td>
<form action="updateAmount.php" method="POST">
						<input type="text" name="amount" value="<?php echo $row['cAmount']; ?>">
						<input type="hidden" name="c" value="<?php echo $row['c_mId']; ?>"><?php////////////////////////////////?>
						<input type="hidden" name="i" value="<?php echo $row['c_iId']; ?>"><?php////////////////////////////////?>
						<input type="submit" name="submit" value="更新">
</form>

  </td>
	<td><?php	echo "$ ",$row['cAmount']*$row2['iUnitPrice'];?></td>
</tr>
<?php
}//if
$_SESSION['totalPrice']+=$row['cAmount']*$row2['iUnitPrice'];
						}

						mysql_close();
						?>

					</table>
		<br>
		總計: <?php echo "$ ",$_SESSION['totalPrice'];?><br>
		運費:
		<?php
		if($_SESSION['totalPrice']>1000){
			echo "$0 (滿千免運)	<br>";
		} else{
			echo "$ 80<br>";
			$_SESSION['totalPrice']+=80;
		}
		?><br>
		本次消費金額: $ <?php echo $_SESSION['totalPrice'];?>
		<br><br>
		<form action="product01.php" >
					<input type="submit" name="submit" value="回首頁">
</form><br>
		<form action="pay.php" >
					<input type="submit" name="submit" value="結帳">
</form>
            </div>

    	</div>
    </body>
</html>
