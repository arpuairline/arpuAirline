﻿<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
		session_start();
		if(!isset($_SESSION['sql'])){
			$_SESSION['sql'] = 0;
		}
?>
<html>
<head>
<title>=Lazipe=</title>
</head>
<body background="img/bggg.png" style="background-repeat:no-repeat; background-position:center;" bgproperties="fixed">
<table border="0" cellpadding="0" cellspacing="0" width="100%" >
	<!--跨三行-->
	<tr>
		<td colspan="3" valign="top">

	<!--顯示輸入帳號的區塊div-->
		<div align="left">
		<img border="0" src="img/top.png" width="45%" height="30%">
		<br /><br />

		<?php
			if(isset($_SESSION['mAccount']) && !empty($_SESSION['mAccount'])){
		?>

					<b><font face="華康采風體W3" size=4>您好！<?php echo $_SESSION['mAccount'];?></font></b>
					<b><font size="3" face="華康采風體W3"><a href="product01.php">  首頁  </a></font></b>
					<b><font size="3" face="華康采風體W3"><a href="Cart.php">  我的購物車  </a></font></b>
					<b><font size="3" face="華康采風體W3"><a href="jj/member.php">  會員中心  </a></font></b>
					<b><font size="3" face="華康采風體W3"><a href="logout.php">  登出</a></font></b>


		<?php
			}else{
		?>
				<form name="form1" method="post" action="jj/connect.php">
						<b><font face="華康采風體W3" size=4>會員登入</font></b>
						<b><font size="3" face="華康采風體W3">帳號</font></b>
						<label>
						  <input name="mAccount" type="text" size="10">
						</label>
							<b><font size="3" face="華康采風體W3">密碼</font></b>
						<label>
						  <input name="mPassword" type="password" size="10">
						  <input type="submit" name="Submit" value="送出">
						</label>
						<a href="jj/register.php"><font size="3" face="華康采風體W3">註冊</font></a>
						<b><font size="3" face="華康采風體W3"><a href="product01.php">  首頁  </a></font></b>
				</form>
		<?php
			}
		?>
		</td>
		</div>
		<tr align="center">
			<td colspan="3" valign="top" >
				<input type="button" value="全部" onclick="location.href='editSession.php?a=0';">
				<input type="button" value="中式甜點" onclick="location.href='editSession.php?a=1';">
				<input type="button" value="西式甜點" onclick="location.href='editSession.php?a=2';">
				<input type="button" value="中式料理" onclick="location.href='editSession.php?a=3';">
				<input type="button" value="西式料理" onclick="location.href='editSession.php?a=4';">
				<input type="button" value="日式料理" onclick="location.href='editSession.php?a=5';">
			</td>
		</tr>
	</tr>


 <!-- 主區塊 START -->
	<td colspan="2" valign="top">
	<div align="center">
	<font face="華康采風體W3">
	<!--show recipe-->
	<table border="0" width="900" height="220">

<?php
	include("db.php");
	$sql = "SELECT `rId`, `rName`, `rType`, `rPic` FROM `recipe`";
	switch ($_SESSION['sql']) {
		case '1':
			$sql = $sql." WHERE `rType` = '中式甜點'";
			break;
		case '2':
			$sql = $sql." WHERE `rType` = '西式甜點'";
			break;
		case '3':
			$sql = $sql." WHERE `rType` = '中式料理'";
			break;
		case '4':
			$sql = $sql." WHERE `rType` = '西式料理'";
			break;
		case '5':
			$sql = $sql." WHERE `rType` = '日式料理'";
			break;
		default:
			$sql = $sql;
			break;
	}
	$result = mysql_query ($sql) or die(mysql_error());
	$data_nums = mysql_num_rows($result);
	$per = 5;
	$pages = ceil($data_nums/$per);
	if (!isset($_GET["page"])){
			$page=1;
	} else {
			$page = intval($_GET["page"]);
	}
	$start = ($page-1)*$per;
	$result = mysql_query($sql.' LIMIT '.$start.', '.$per) or die(mysql_error());
	while ($row = mysql_fetch_array($result))
	{
?>

	<tr>
		<!--img-->
		<td align="center" height="220" width="200">
				<input type="image"  width="150px" height="150px" name="rId" border="0" src="img/recipe/<?php echo $row['rPic'];?>"  onClick="location.href='product02.php?no=<?php echo $row['rId'];?>';" />
		</td>
		<!--detail-->
		<td align="left" height="55" width="200">
			<p><b><?php echo $row['rName'];?></b></p>
			<p><b><?php echo $row['rType'];?></b></p>
		</td>
	</tr>

<?php
	} //end while
	mysql_close();
?>
	</table>
	</font>
	<?php
	//分頁
	    echo "第 ";
	    for( $i=1 ; $i<=$pages ; $i++ ) {
	        if ( $page-3 < $i && $i < $page+3 ) {
	            echo "<a href=?page=".$i.">".$i."</a> ";
	        }
	    }
			echo '頁<br>目前在第 '.$page.' 頁，共'.$pages.'頁<br>';
	 ?>
	</div>
	</td>
  <!-- 主區塊 END -->
	</tr>
</table>
</body>
</html>
