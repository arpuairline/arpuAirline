

<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();
	$payment= $_POST['payment'];
	$_SESSION['tPayMethod'] = $payment;
	$mAccount=$_SESSION['mAccount'];

?>
<head>
    	<link rel="stylesheet" href="CSS/reset.css" />
        <link rel="stylesheet" href="CSS/style.css" />
        <title>address</title>
</head>
<body>

	<div id="container">

    <h1>請確認收件資料</h1>
<?php
		include("db.php");
		$sql="SELECT * FROM `member` WHERE `mAccount`='$mAccount'";
		$query=mysql_query($sql);
		$row = mysql_fetch_array($query);
    mysql_close();

    $dName=$row['mName'];//select mName
    $dAdd=$row['mAddress'];//select mAdd
    $dPhone=$row['mPhone'];//select mPhone
?>
    <form action="insertOrder.php" method="post">
  		姓名: <input type="text" name="mName" value=<?php echo $dName; ?>><br>
  		地址: <input type="text" name="mAdd" value=<?php echo $dAdd; ?>><br>
        電話: <input type="text" name="mPhone" value=<?php echo $dPhone; ?>><br>
  		<input type="submit" value="確認">
	</form>
    <br>
    		<form action="pay.php" >
                <input type="submit" name="backToPay" value="上一步">
			</form>
    <br><br>
    <table>

    <tr>
        <td>付款方式 : </td>
        <td>
        <?php
	    if($payment != null){
    		if($payment == 0){
				echo "ATM <br> 台灣銀行政大分行（005）<br>銀行帳號：1234567890";
			}else{
				echo "貨到付款";
			}
		}else{
			echo "請選擇付款方式！";
		}

    ?>
        </td>
    </tr>

    </table>
    <br><br><h4>本次消費金額 : </h4>
<?php

	if(isset($_SESSION['totalPrice']) && !empty($_SESSION['totalPrice'])){
		echo "$", $_SESSION['totalPrice'];
	}
?>
<br><br>
<?php
      $datetime = date ("Y-m-d H:i:s" , mktime(date('H')+6, date('i'), date('s'), date('m'), date('d'), date('Y'))) ;
			$_SESSION['time']= $datetime;
			echo $_SESSION['time'];
?>
    </div>
</body>
