

<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();

?>
<head>
    	<link rel="stylesheet" href="CSS/reset.css" />
        <link rel="stylesheet" href="CSS/style.css" />
        <title>pay</title>
</head>
<body>

	<div id="container"><h1>選擇您要的付款方式</h1>
        	<form action="checkAddress.php" method="POST">
  				<input type="radio" name="payment" value="0">ATM<br>
  				<input type="radio" name="payment" value="1" checked>貨到付款<br><br>
                <input type="submit" name="submit" value="下一步">
			</form>
            <br>

            <form action="Cart.php">
                <input type="submit" name="submit" value="回到購物車">
			</form>
	<br><br><h4>本次消費金額 : </h4>
<?php

	if(isset($_SESSION['totalPrice']) && !empty($_SESSION['totalPrice'])){
		echo "$", $_SESSION['totalPrice'];
	}
?>
<br><br>
<?php
            //$datetime = date ("Y-m-d" , mktime(date('m'), date('d'), date('Y'))) ;
						$datetime = date ("Y-m-d H:i:s" , mktime(date('H')+6, date('i'), date('s'), date('m'), date('d'), date('Y'))) ;
			$_SESSION['time']= $datetime;
			echo $_SESSION['time'];
?>
    </div>
</body>
