<?php
$hostname= "localhost";	//主機名稱
$database= "test";		//資料庫名稱
$username= "";		//資料庫登入帳號
$password= "";	//資料庫登入密碼

//開啟MySQL伺服器連結，mysql_connect()函式依序是放入剛剛設定的變數$hostname, $username, $password，後面的trigger_error()函式是可當資料庫連結發生問題可以回傳錯誤訊息
$link = mysql_connect($hostname, $username, $password) or die("fail to connect".mysql_error());
mysql_query("set names utf8");	//使用mysql_query()函式送出一個字串到資料庫，將資料庫設定為utf8編碼，防止中文亂碼產生
if(mysql_select_db($database, $link))
  echo "";
//mysql_select_db()函式選擇一個資料庫進行連結
//$sql ="INSERT INTO `Transaction` (`tId`, `tTime`, `tTotalPrice`, `tPayMethod`) VALUES (NULL, '2016-05-02', '50', '0')";
//$query = mysql_query($sql);

?>
