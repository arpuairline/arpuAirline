<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">

<?php
	session_start();
  include("db.php");
	$mId=$_SESSION['mID'];
	$_SESSION['name']= $_POST['mName'];
	$_SESSION['address']= $_POST['mAdd'];
	$_SESSION['phone']= $_POST['mPhone'];
  $_SESSION['orderNum']=rand(1000,10000);//********************
	$_SESSION['inserTime']=NULL;

	$sql="SELECT * FROM `cart` WHERE `c_mId`='$mId'";
	$query=mysql_query($sql);
	while($row = mysql_fetch_array($query)){

	$idnum=$row['c_iId'];
	$sql2="SELECT `iName`,`iSource`,`iUnitPrice` FROM `ingredients` WHERE `iId`='$idnum'";
	$query2=mysql_query($sql2);
	while($row2 = mysql_fetch_array($query2)){
		if($_SESSION['inserTime']==NULL){
		$datetime = date ("Y-m-d H:i:s" , mktime(date('H')+6, date('i'), date('s'), date('m'), date('d'), date('Y'))) ;//test
		$_SESSION['inserTime']= $datetime;//test

		$sql3="INSERT INTO `transaction2`(`tId`, `tTime`, `tTotalPrice`, `tPayMethod`, `tName`, `tPhone`, `tAdd`, `t_iName`, `t_iAmount`, `t_mId`) VALUES (NULL,'".$_SESSION['inserTime']."','".$_SESSION['totalPrice']."','".$_SESSION['tPayMethod']."','".$_SESSION['name']."','".$_SESSION['phone']."','".$_SESSION['address']."','".$row2['iName']."','".$row['cAmount']."','".$mId."')";
		$query3=mysql_query($sql3);
		}else{
			$datetime = date ("Y-m-d H:i:s" , mktime(date('H')+6, date('i'), date('s'), date('m'), date('d'), date('Y'))) ;//test
			$_SESSION['inserTime']= $datetime;//test
		  
			$sql3="INSERT INTO `transaction2`(`tId`, `tTime`, `tTotalPrice`, `tPayMethod`, `tName`, `tPhone`, `tAdd`, `t_iName`, `t_iAmount`, `t_mId`) VALUES (NULL,'".$_SESSION['inserTime']."','".$_SESSION['totalPrice']."','".$_SESSION['tPayMethod']."','".$_SESSION['name']."','".$_SESSION['phone']."','".$_SESSION['address']."','".$row2['iName']."','".$row['cAmount']."','".$mId."')";
			$query3=mysql_query($sql3);
		}
	}

}

?>
<script language='javascript'>location.href='temp.php';</script>
