<?php
    session_start();
    $_SESSION['sql'] = $_GET['a'];
    echo "<script language='javascript'>location.href='product01.php';</script>";
?>
