

<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();
	$mId=$_SESSION['mID'];

?>

<head>
    	<link rel="stylesheet" href="CSS/reset.css" />
      <link rel="stylesheet" href="CSS/style.css" />
      <title>confirm</title>
</head>
<body>
	<div id="container"><h1>訂單完成</h1>
    <?php

		include("db.php");

		//從購物車刪除
		$sql="DELETE FROM `cart` WHERE `c_mId`='$mId'";
		$query=mysql_query($sql);

		echo "收件人資料 : <br>";
		echo $_SESSION['name'],"<br>";
		echo $_SESSION['address'],"<br>";
		echo $_SESSION['phone'],"<br><br>";
		echo "消費日期 : <br>";
		echo $_SESSION['time'];
		echo "<br><br>";
		echo "本次消費金額 : <br>";
		echo "$", $_SESSION['totalPrice'];
		echo "<br><br>付款方式 :<br>";

			if($_SESSION['tPayMethod']==0){
				echo "ATM";
			}else{
				echo "貨到付款";
			}

			?>
            <br><br><br>
            <form action="product01.php" >
                <input type="submit" name="goIndex" value="回首頁">
			</form>



    </div>
</body>
