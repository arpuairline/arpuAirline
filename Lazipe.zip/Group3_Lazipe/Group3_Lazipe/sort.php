

<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<?php
	session_start();
  include("db.php");
?>
<head>
    	<link rel="stylesheet" href="CSS/reset.css" />
        <link rel="stylesheet" href="CSS/style.css" />
        <title>sort</title>
</head>
<body>

	<div id="container">
		<?php
$datetime = date ("Y-m-d H:i:s" , mktime(date('H')+6, date('i'), date('s'), date('m'), date('d'), date('Y'))) ;
echo $datetime;
?>
		<?php
		 $sql="SELECT * FROM `transaction2`ORDER BY `tId` ASC";
		 $query=mysql_query($sql);

		 while($row = mysql_fetch_array($query)){

		 //echo $row['tTime'],"<br>";
		 }
		 	?>
  </div>
</body>
