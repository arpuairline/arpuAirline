<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<html>
<head><title>Add to Cart</title></head>
<body>
<?php
session_start();
$rId = $_POST['r_id'];
$iId = $_POST['i_id'];
//$mId = $_SESSION['mID'];

if(isset($_SESSION['mID']) && !empty($_SESSION['mID'])){
	//$mId = $_SESSION['mID'];
	include("db.php");
	$sql_check = "SELECT count(*) AS row FROM `cart` WHERE `c_mId` = ".$_SESSION['mID']." AND `c_iId` =".$iId.";";
	$result_check = mysql_query($sql_check);
	$row = mysql_fetch_row($result_check);
	if($row[0]>0){
		echo "<script language='javascript'>alert('已經加入過囉');location.href='product02.php?no=".$rId."';</script>";
	}else {
		$sql="INSERT INTO `cart`(`c_mId`, `cTime`, `c_iId`, `cAmount`) VALUES (".$_SESSION['mID'].",NULL,$iId,1);";
		if(mysql_query($sql))
		{
			echo "<script language='javascript'>alert('加入成功囉');location.href='product02.php?no=".$rId."';</script>";
		}else {
			echo mysql_query($sql).mysql_error();
		}//end-else
	}//end-else
	mysql_close();
}else {
	echo "<script language='javascript'>alert('親，要登入才可以使用購物車呦0_<');location.href='product02.php?no=".$rId."';</script>";
}
?>
</body>
</html>
