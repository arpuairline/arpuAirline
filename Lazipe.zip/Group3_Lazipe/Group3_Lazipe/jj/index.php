
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<form name="form" method="post" action="connect.php">

<body>


<div style="text-align: center;">
<img src="http://give5.info/uploads/image/201510/20151006205005_42908.jpg" width="130" height="150">
<h1 style="text-align: center;">會員登入</h1>
	<p>
		<label for="user_login">帳號：<br />
		<input type="text" name="mAccount" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">密碼：<br />
		<input type="password" name="mPassword" class="input" value="" size="20" /></label>
	</p>

<input type="submit" name="button" value="登入" />&nbsp;&nbsp;
<a href="register.php">申請帳號</a>

</div>
</body>


</form>
