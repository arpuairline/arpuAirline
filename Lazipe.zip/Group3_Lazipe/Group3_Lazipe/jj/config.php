<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
mysql_connect("localhost", "", "");
mysql_select_db("test");
mysql_query("SET NAMES utf8");
?>
