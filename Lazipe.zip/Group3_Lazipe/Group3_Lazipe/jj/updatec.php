﻿<?php 
session_start();
include("config.php"); 

$mAccount = $_POST['mAccount'];
$mName = $_POST['mName'];
$mPassword = $_POST['mPassword'];
$mAddress = $_POST['mAddress'];
$mPhone = $_POST['mPhone'];


$sql = "SELECT * FROM member where mAccount='$mAccount'";
$result = mysql_query($sql);
$row = mysql_fetch_row($result);

if($mPassword==null)
{
$mPassword = $row[2];
}

//確認手機是否重複與位數是否正確
if(strlen($mPhone) == 9){
    exit('錯誤！手機不符合規定（必須10碼）。<a href="javascript:history.back(-1);">返回</a>');
}

$sql = "UPDATE member SET mName = '$mName', mPassword = '$mPassword' ,mAddress = '$mAddress', mPhone = '$mPhone' WHERE mAccount='$mAccount';";
if(mysql_query($sql))
{
echo"<font color='green'>更新成功！</font>";
echo'<meta http-equiv="refresh" content="2; url=member.php">';
}
else
{
echo"<font color='red'>更新失敗！</font>";
echo'<meta http-equiv="refresh" content="2; url=member.php">';
}

?>