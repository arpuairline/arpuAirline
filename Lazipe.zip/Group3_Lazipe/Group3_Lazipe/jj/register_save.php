<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php


include("config.php");

$mAccount=$_POST['mAccount'];
$mPassword=$_POST['mPassword'];
$mName=$_POST['mName'];
$mAddress=$_POST['mAddress'];
$mPhone=$_POST['mPhone'];



//確認密碼長度
if(strlen($mPassword) < 6){
    exit('錯誤！密碼不符合規定。<a href="javascript:history.back(-1);">返回</a>');
}

//用戶存在與否確認
$check_query = mysql_query("select mAccount from member where mAccount='$mAccount' limit 1");
if(mysql_fetch_array($check_query)){
    echo '錯誤！使用者名稱 ',$mAccount,' 已存在。<a href="javascript:history.back(-1);">返回</a>';
    exit;
}
//確認手機是否重複與位數是否正確
if(strlen($mPhone) == 9){
    exit('錯誤！手機不符合規定（必須10碼）。<a href="javascript:history.back(-1);">返回</a>');
}
$check_query = mysql_query("select mPhone from member where mPhone='$mPhone' limit 1");
if(mysql_fetch_array($check_query)){
    echo '錯誤！此手機 ',$mPhone,' 已註冊過了。<a href="javascript:history.back(-1);">返回</a>';
    exit;
}

//寫入資料
$sql = "INSERT INTO member(mAccount,mPassword,mName,mAddress,mPhone)VALUES('$mAccount','$mPassword','$mName',
'$mAddress','$mPhone')";
if(mysql_query($sql)){
    exit('註冊成功！請回首頁 <a href="http://140.119.19.56:8080/ADB2/product01.php">登入</a>');
} else {
    echo '資料添加失敗，原因請見：',mysql_error(),'<br />';
    echo '點擊此處 <a href="javascript:history.back(-1);">返回</a> 重試';
}

?>
