﻿<!-- <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> -->
<html>

<head>
<meta content="text/html; charset=UTF8" http-equiv="content-type">
<title>更新帳號資訊</title>
</head>

<body>
<h1 style="text-align: center;">更新帳號資訊</h1>
<div style="text-align: center;">
<?php
session_start();
include("config.php"); 
$mAccount = $_SESSION['mAccount'];
$sql = "SELECT * FROM member where mAccount='$mAccount'";
$result = mysql_query($sql);
$row = mysql_fetch_row($result);
if($_SESSION['mAccount']!=null)
{
?>
<form method="post" action="updatec.php" name="reg">
<table style="text-align: center; width: 100px; margin-left: auto; margin-right: auto;" border="1" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;">
帳號:<input name="mAccount" type="text" readonly="readonly" value="<?php echo $row[1];?>"><br>
密碼:<input name="mPassword" type="password"><br>
姓名:<input name="mName" type="text" value="<?php echo $row[3];?>"><br>
地址:<input name="mAddress" type="text" value="<?php echo $row[4];?>"><br>
電話:<input name="mPhone" type="text" value="<?php echo $row[5];?>"><br>

<input name="reg" value="更新" type="submit"><br>
</td>
</tr>
</tbody>
</table>
</form>
<?php 
}
else
{
?>
<font color="red">您尚未登入！</font>
<?php
}
?>
</div>
</body>

</html>