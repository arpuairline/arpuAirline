<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<form name="form" method="post" action="register_save.php">
帳號：<input type="text" name="mAccount" /> <br>
密碼（六個以上的數字與英文字母的組合）：<input type="password" name="mPassword" /> <br>
姓名：<input type="text" name="mName" /> <br>
地址：<input type="text" name="mAddress" /> <br>
電話：<input type="text" name="mPhone" /> <br>

<input type="submit" name="button" value="註冊" />&nbsp;&nbsp;
<a href="../product01.php">回到首頁</a>
</form>
