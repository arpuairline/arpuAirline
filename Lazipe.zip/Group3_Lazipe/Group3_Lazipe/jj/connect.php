<?php session_start(); ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

include("config.php");

$mAccount=$_POST['mAccount'];
$mPaasword=$_POST['mPassword'];
$sql = "SELECT * FROM Member where mAccount = '$mAccount'";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);


if($mAccount!= '' &&$mPaasword!= ''&&$mAccount==$row[1]&&$row[2]==$mPaasword){
$_SESSION['mAccount'] =$mAccount;
$_SESSION['mID'] =$row[0];
echo '登入成功!';
echo "<meta http-equiv=REFRESH CONTENT=1;url=../product01.php>";
}
else
{

echo "登入失敗!";
echo "<meta http-equiv=REFRESH CONTENT=1;url=../product01.php>";
}

?>
